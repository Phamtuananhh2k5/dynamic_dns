<?php
$host = 'localhost';
$dbname = 'ddns_system';
$username = 'ddns'; // Thay bằng tài khoản MySQL của bạn
$password = 'Hoilamgi@12345';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Kết nối CSDL thất bại: " . $e->getMessage());
}
?>