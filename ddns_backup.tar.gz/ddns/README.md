# ddns

## Giới thiệu
Dự án DDNS (Dynamic DNS) là một hệ thống cho phép người dùng đăng ký, đăng nhập và quản lý các subdomain của họ một cách linh hoạt. Hệ thống này sử dụng PHP và MySQL để lưu trữ và xử lý dữ liệu.

## Chức năng chính
- **Đăng ký tài khoản**: Người dùng có thể tạo tài khoản mới bằng cách cung cấp tên đăng nhập và mật khẩu.
- **Đăng nhập**: Người dùng có thể đăng nhập vào hệ thống bằng tên đăng nhập và mật khẩu đã đăng ký.
- **Tạo subdomain**: Người dùng có thể tạo subdomain mới bằng cách cung cấp thông tin subdomain và địa chỉ IP.
- **Cập nhật IP cho subdomain**: Người dùng có thể cập nhật địa chỉ IP cho subdomain đã tạo thông qua API.

## Cài đặt
### Yêu cầu
- PHP 7.x hoặc cao hơn
- MySQL

### Hướng dẫn cài đặt
1. **Clone repository**:
    ```sh
    git clone https://github.com/Phamtuananhh2k5/ddns.git
    cd ddns
    ```

2. **Cài đặt các gói cần thiết**:
    - Đảm bảo bạn đã cài đặt Composer, sau đó chạy:
    ```sh
    composer install
    ```

3. **Cấu hình cơ sở dữ liệu MySQL**:
    - Tạo cơ sở dữ liệu và các bảng:
    ```sql
    CREATE DATABASE ddns;
    USE ddns;

    CREATE TABLE users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(255) NOT NULL,
        password VARCHAR(255) NOT NULL
    );

    CREATE TABLE subdomains (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        subdomain VARCHAR(255) NOT NULL,
        ip VARCHAR(255) NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users(id)
    );
    ```

4. **Cấu hình kết nối cơ sở dữ liệu trong tệp `.env`**:
    ```env
    DB_HOST=localhost
    DB_USER=root
    DB_PASS=
    DB_NAME=ddns
    ```

5. **Chạy server**:
    - Sử dụng PHP built-in server hoặc cấu hình Apache/Nginx phù hợp:
    ```sh
    php -S localhost:8000 -t public
    ```

## Sử dụng
### Đăng ký tài khoản
- Endpoint: `/register`
- Method: `POST`
- Dữ liệu yêu cầu:
    ```json
    {
        "username": "your_username",
        "password": "your_password"
    }
    ```

### Đăng nhập
- Endpoint: `/login`
- Method: `POST`
- Dữ liệu yêu cầu:
    ```json
    {
        "username": "your_username",
        "password": "your_password"
    }
    ```

### Tạo subdomain
- Endpoint: `/create-subdomain`
- Method: `POST`
- Dữ liệu yêu cầu:
    ```json
    {
        "user_id": 1,
        "subdomain": "your_subdomain",
        "ip": "your_ip"
    }
    ```

### Cập nhật IP cho subdomain
- Endpoint: `/update-subdomain`
- Method: `POST`
- Dữ liệu yêu cầu:
    ```json
    {
        "secret": "your_secret",
        "domain": "your_domain",
        "addr": "new_ip_address"
    }
    ```

## Đóng góp
Nếu bạn muốn đóng góp vào dự án, hãy fork repository này và gửi pull request của bạn. Mọi ý kiến đóng góp đều được hoan nghênh!

## Giấy phép
Dự án này được cấp phép theo giấy phép MIT. Xem tệp LICENSE để biết thêm chi tiết.
