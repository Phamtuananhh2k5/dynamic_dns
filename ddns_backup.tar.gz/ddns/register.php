<?php
include 'config.php';
require 'vendor/autoload.php'; // Đảm bảo PHPMailer đã được cài qua Composer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Đặt cấu hình ghi log lỗi
ini_set('display_errors', 1); // Hiển thị lỗi trên trình duyệt
error_reporting(E_ALL); // Báo cáo tất cả lỗi

// Đường dẫn đến file log lỗi
$logFile = '/var/www/ddns/error_log.txt';

function logError($message) {
    global $logFile;
    file_put_contents($logFile, date('Y-m-d H:i:s') . " - " . $message . "\n", FILE_APPEND);
}

// Kiểm tra mật khẩu mạnh
function isStrongPassword($password) {
    // Kiểm tra mật khẩu ít nhất 8 ký tự, có ít nhất 1 chữ cái viết hoa, 1 chữ cái viết thường, 1 số và 1 ký tự đặc biệt
    return preg_match('/[A-Z]/', $password) && 
           preg_match('/[a-z]/', $password) && 
           preg_match('/[0-9]/', $password) && 
           preg_match('/[\W_]/', $password) && 
           strlen($password) >= 8;
}

// Đăng ký người dùng và gửi email xác minh
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Lấy thông tin người dùng từ form
    $username = trim($_POST['username']);
    $password = str_replace(' ', '', $_POST['password']); // Loại bỏ ký tự trống trong mật khẩu
    $email = $_POST['email'];

    // Kiểm tra mật khẩu đủ mạnh
    if (!isStrongPassword($password)) {
        $message = "Mật khẩu phải có ít nhất 8 ký tự, bao gồm 1 chữ cái viết hoa, 1 số và 1 ký tự đặc biệt.";
        $messageType = "error";
    } else {
        try {
            // Kiểm tra tên đăng nhập đã tồn tại chưa
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = :username");
            $stmt->execute(['username' => $username]);
            $userExists = $stmt->fetchColumn();

            if ($userExists) {
                $message = "Tên đăng nhập đã tồn tại. Vui lòng chọn tên khác.";
                $messageType = "error";
            } else {
                // Kiểm tra email đã tồn tại chưa
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = :email");
                $stmt->execute(['email' => $email]);
                $emailExists = $stmt->fetchColumn();

                if ($emailExists) {
                    $message = "Email đã được sử dụng. Vui lòng chọn email khác.";
                    $messageType = "error";
                } else {
                    // Mã hóa mật khẩu
                    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

                    // Tạo mã xác minh ngẫu nhiên (128 ký tự)
                    $verificationCode = bin2hex(random_bytes(64)); // 128 ký tự

                    // Lưu thông tin người dùng vào cơ sở dữ liệu
                    $stmt = $pdo->prepare("INSERT INTO users (username, password, email, verification_code) VALUES (:username, :password, :email, :verification_code)");
                    $stmt->execute([ 
                        'username' => $username,
                        'password' => $hashedPassword,
                        'email' => $email,
                        'verification_code' => $verificationCode
                    ]);

                    // Gửi email xác minh
                    $mail = new PHPMailer(true);
                    try {
                        $mail->isSMTP();
                        $mail->Host = 'smtp.gmail.com';
                        $mail->SMTPAuth = true;
                        $mail->Username = 'mail.check.block.dualeo@gmail.com';
                        $mail->Password = 'uzqamacikbqqufhl';
                        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                        $mail->Port = 587;

                        // Người gửi và người nhận
                        $mail->setFrom('mail.check.block.dualeo@gmail.com', 'Tên ứng dụng');
                        $mail->addAddress($email);

                        // Tạo liên kết xác minh
                        $verificationLink = "http://ddns.bichan.site/verify_account.php?code=$verificationCode";

                        // Nội dung email
                        $mail->isHTML(true);
                        $mail->Subject = 'Liên kết xác minh tài khoản';
                        $mail->Body    = "Vui lòng nhấp vào liên kết sau để xác minh tài khoản của bạn: <a href='$verificationLink'>$verificationLink</a>";

                        // Gửi email
                        $mail->send();

                        $message = "Đăng ký thành công! Liên kết xác minh đã được gửi tới email của bạn.";
                        $messageType = "success";
                        header("refresh:1;url=login.php");
                        exit();
                    } catch (Exception $e) {
                        $message = "Không thể gửi email. Lỗi: {$mail->ErrorInfo}";
                        $messageType = "error";
                    }
                }
            }
        } catch (Exception $e) {
            $message = "Đã xảy ra lỗi: " . $e->getMessage();
            $messageType = "error";
        }
    }
}

?>

<!-- Thêm liên kết CSS -->
<head>
    <link rel="stylesheet" type="text/css" href="/assets/css/register-style.css">
</head>

<!-- Form đăng ký -->
<form method="POST">
    <h2>Đăng Ký</h2>

    <label for="username">Tên đăng nhập:</label>
    <input type="text" name="username" id="username" required><br>

    <label for="password">Mật khẩu:</label>
    <input type="password" name="password" id="password" required><br>

    <label for="email">Email:</label>
    <input type="email" name="email" id="email" required><br>

    <button type="submit">Đăng ký</button>

    <?php if (isset($message)): ?>
        <!-- Hiển thị thông báo lỗi hoặc thành công -->
        <div class="<?php echo htmlspecialchars($messageType); ?>">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>
</form>
