<?php
include 'config.php';

// Kiểm tra nếu mã xác minh được gửi qua URL
if (isset($_GET['code'])) {
    $verificationCode = $_GET['code'];

    try {
        // Kiểm tra mã xác minh trong cơ sở dữ liệu
        $stmt = $pdo->prepare("SELECT id, verification_code FROM users WHERE verification_code = :verification_code");
        $stmt->execute(['verification_code' => $verificationCode]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            // Cập nhật trạng thái tài khoản là đã xác minh
            $stmt = $pdo->prepare("UPDATE users SET is_verified = 1 WHERE id = :id");
            $stmt->execute(['id' => $user['id']]);

            // Thông báo thành công và chuyển hướng tới trang đăng nhập
            echo "Tài khoản của bạn đã được xác minh thành công!";
            header("refresh:3;url=login.php");  // Chuyển hướng sau 3 giây
            exit(); // Dừng thực thi mã sau khi chuyển hướng
        } else {
            // Thông báo mã xác minh không hợp lệ
            echo "Mã xác minh không hợp lệ!";
        }
    } catch (Exception $e) {
        echo "Lỗi: " . $e->getMessage();
    }
} else {
    echo "Mã xác minh không hợp lệ!";
}
?>
