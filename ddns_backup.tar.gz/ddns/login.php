<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập</title>
    <link rel="stylesheet" href="/assets/css/login-style.css">
</head>
<body>

    <?php
    include 'config.php';
    session_start();

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username");
        $stmt->execute(['username' => $username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            echo "<p>Đăng nhập thành công!</p>";
            header("Location: create_subdomain.php"); // Redirect to create_subdomain.php after successful login
            exit();
        } else {
            echo "<p class='error-message'>Tên đăng nhập hoặc mật khẩu không đúng!</p>";
        }
    }
    ?>

    <form method="POST">
        <h2>Đăng nhập vào hệ thống</h2>
        <input type="text" name="username" placeholder="Tên đăng nhập" required><br>
        <input type="password" name="password" placeholder="Mật khẩu" required><br>
        <button type="submit">Đăng nhập</button>
    </form>

</body>
</html>
