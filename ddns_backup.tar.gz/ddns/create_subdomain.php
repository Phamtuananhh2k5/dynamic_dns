<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tạo Subdomain</title>
    <link rel="stylesheet" href="/assets/css/create_subdomain-style.css">
</head>
<body>

<?php
include 'config.php';
session_start();

// Kiểm tra người dùng đã đăng nhập chưa
if (!isset($_SESSION['user_id'])) {
    die("Vui lòng đăng nhập trước!");
}

// Hàm gửi yêu cầu API sử dụng cURL
function send_api_request($url) {
    $command = "curl -s \"$url\""; // -s để ẩn thông tin tiến trình
    $response = shell_exec($command);
    return $response;
}

// Hàm kiểm tra IP hợp lệ
function validate_ip($ip_address) {
    return filter_var($ip_address, FILTER_VALIDATE_IP);
}

// Hàm tạo subdomain mới
function create_subdomain($pdo, $user_id, $subdomain_name, $ip_address) {
    if (!validate_ip($ip_address)) {
        return "Địa chỉ IP không hợp lệ. Vui lòng nhập lại.";
    }

    // Kiểm tra subdomain đã tồn tại chưa
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM subdomains WHERE subdomain_name = :subdomain_name");
    $stmt->execute(['subdomain_name' => $subdomain_name]);
    $subdomain_exists = $stmt->fetchColumn();

    if ($subdomain_exists) {
        return "Subdomain đã được sử dụng!";
    } else {
        // Thêm subdomain vào cơ sở dữ liệu
        $stmt = $pdo->prepare("INSERT INTO subdomains (user_id, subdomain_name, ip_address) VALUES (:user_id, :subdomain_name, :ip_address)");
        $stmt->execute([
            'user_id' => $user_id,
            'subdomain_name' => $subdomain_name,
            'ip_address' => $ip_address
        ]);
        
        // Gửi API cập nhật IP
        $secret = "X7QY29RJL5MGND8PC3VW";
        $url = "http://103.82.133.200:8080/update?secret=$secret&domain=$subdomain_name&addr=$ip_address";
        $response = send_api_request($url);

        return "Subdomain đã được tạo và cập nhật IP!";
    }
}

// Hàm cập nhật IP cho subdomain
function update_subdomain($pdo, $user_id, $subdomain_id, $new_ip_address) {
    if (!validate_ip($new_ip_address)) {
        return "Địa chỉ IP không hợp lệ. Vui lòng nhập lại.";
    }

    // Cập nhật IP mới cho subdomain trong cơ sở dữ liệu
    $stmt = $pdo->prepare("UPDATE subdomains SET ip_address = :ip_address WHERE id = :id AND user_id = :user_id");
    $stmt->execute([
        'ip_address' => $new_ip_address,
        'id' => $subdomain_id,
        'user_id' => $user_id
    ]);

    // Gửi API cập nhật IP mới
    $secret = "X7QY29RJL5MGND8PC3VW";
    $stmt = $pdo->prepare("SELECT subdomain_name FROM subdomains WHERE id = :id");
    $stmt->execute(['id' => $subdomain_id]);
    $subdomain_name = $stmt->fetchColumn();
    $url = "http://103.82.133.200:8080/update?secret=$secret&domain=$subdomain_name&addr=$new_ip_address";
    $response = send_api_request($url);

    return "IP của subdomain đã được cập nhật!";
}

// Hàm xóa subdomain
function delete_subdomain($pdo, $user_id, $subdomain_id) {
    $stmt = $pdo->prepare("DELETE FROM subdomains WHERE id = :id AND user_id = :user_id");
    $stmt->execute([
        'id' => $subdomain_id,
        'user_id' => $user_id
    ]);

    return "Subdomain đã được xóa!";
}

// Xử lý yêu cầu POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id'];

    if (isset($_POST['create_subdomain'])) {
        $subdomain_name = $_POST['subdomain_name'];
        $ip_address = $_POST['ip_address'];
        $message = create_subdomain($pdo, $user_id, $subdomain_name, $ip_address);
    } elseif (isset($_POST['update_subdomain'])) {
        $subdomain_id = $_POST['subdomain_id'];
        $new_ip_address = $_POST['new_ip_address'];
        $message = update_subdomain($pdo, $user_id, $subdomain_id, $new_ip_address);
        header("Location: create_subdomain.php");
        exit();
    } elseif (isset($_POST['delete_subdomain'])) {
        $subdomain_id = $_POST['subdomain_id'];
        $message = delete_subdomain($pdo, $user_id, $subdomain_id);
        header("Location: create_subdomain.php");
        exit();
    }
}

// Lấy danh sách subdomains của user
$stmt = $pdo->prepare("SELECT * FROM subdomains WHERE user_id = :user_id");
$stmt->execute(['user_id' => $_SESSION['user_id']]);
$subdomains = $stmt->fetchAll();
?>

<div class="container">
    <h2>Tạo Subdomain mới</h2>
    <form method="POST">
        <div class="form-group">
            <label for="subdomain_name">Tên Subdomain:</label>
            <input type="text" id="subdomain_name" name="subdomain_name" required>
        </div>
        <div class="form-group">
            <label for="ip_address">Địa chỉ IP:</label>
            <input type="text" id="ip_address" name="ip_address" required>
        </div>
        <button type="submit" name="create_subdomain">Tạo Subdomain</button>
    </form>

    <?php if (isset($message)): ?>
        <p class="message"><?php echo $message; ?></p>
    <?php endif; ?>

    <h2>Danh sách Subdomain của bạn</h2>
    <table>
        <thead>
            <tr>
                <th>Tên Subdomain</th>
                <th>Địa chỉ IP</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($subdomains as $subdomain): ?>
                <tr>
                    <td><?php echo htmlspecialchars($subdomain['subdomain_name']) . '.dyndns.bichan.site'; ?></td>
                    <td><?php echo htmlspecialchars($subdomain['ip_address']); ?></td>
                    <td>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="subdomain_id" value="<?php echo $subdomain['id']; ?>">
                            <label for="new_ip_address_<?php echo $subdomain['id']; ?>">Địa chỉ IP mới:</label>
                            <input type="text" name="new_ip_address" id="new_ip_address_<?php echo $subdomain['id']; ?>" required>
                            <button type="submit" name="update_subdomain">Cập nhật IP</button>
                        </form>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="subdomain_id" value="<?php echo $subdomain['id']; ?>">
                            <button type="submit" name="delete_subdomain">Xóa</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

</body>
</html>
